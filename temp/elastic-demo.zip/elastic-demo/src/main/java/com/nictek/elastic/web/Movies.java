package com.nictek.elastic.web;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import java.io.Serializable;

@Data
@Document(indexName = "movies",type = "_doc")
public class Movies implements Serializable {

    @Id//必须有id注解
    private String id;
    private String title;
    private int year;
    private String genre;
} 
