package com.nictek.elastic.web;

import com.alibaba.fastjson.JSONObject;
import org.elasticsearch.index.query.QueryStringQueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.time.LocalDateTime;
import java.util.Iterator;

/**
 * @author niko
 * @version 0.1
 * @date 2020/11/6
 */
@Controller
public class HandleController {

    @Autowired
    private MoviesRepository moviesRepository;

    @Autowired
    private WebchatProfileRepository webchatProfileRepository;

    @GetMapping("/queryMovie")
    @ResponseBody
    public JSONObject queryMovies(){


        QueryStringQueryBuilder queryBuilder =
                new QueryStringQueryBuilder("Batman");
        queryBuilder.defaultField("title");

        Page<Movies>  page = moviesRepository.search(queryBuilder,
                PageRequest.of(0,50));
        for(Iterator<Movies> iter = page.iterator();iter.hasNext();){
            Movies movies = iter.next();
            System.out.println(movies.getTitle() + ":" + movies.getYear());
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("size",page.getSize());
        jsonObject.put("list",page.getContent());
        return  jsonObject;
    }


    @GetMapping("/query")
    @ResponseBody
    public JSONObject query(){

        QueryStringQueryBuilder queryBuilder =
                new QueryStringQueryBuilder("2398923402612");
        queryBuilder.defaultField("openid");

        Page<WebchatProfile>  page = webchatProfileRepository.search(queryBuilder,
                PageRequest.of(0,50));
        for(Iterator<WebchatProfile> iter = page.iterator();iter.hasNext();){
            WebchatProfile profile = iter.next();
            System.out.println(profile.getUserGroupId() + ":" + profile.getOpenId());
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("size",page.getSize());
        jsonObject.put("list",page.getContent());
        return  jsonObject;
    }

    public static void main(String[] args) {
        System.out.println(System.currentTimeMillis());
    }
}
