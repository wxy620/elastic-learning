package com.nictek.elastic.web;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MoviesRepository extends ElasticsearchRepository<Movies, String> {

}
