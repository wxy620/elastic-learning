package com.nictek.elastic.web;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * @author niko
 * @version 0.1
 * @date 2020/11/6
 */
public interface WebchatProfileRepository extends ElasticsearchRepository<WebchatProfile, String> {
}
