package com.nictek.elastic.web;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;

import java.io.Serializable;
import java.util.Date;

/**
 * @author niko
 * @version 0.1
 * @date 2020/11/6
 */
@Data
@Document(indexName = "userprofile_sys_usergroup_webchat")
public class WebchatProfile implements Serializable {

    @Id
    String id;

    @Field("openid")
    String openId;

    @Field("unionid")
    String unionId ;

    @Field("usergroupid")
    String userGroupId;

    @Field(value = "data_date")
    long  dateTime;


}
